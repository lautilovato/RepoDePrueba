from setuptools import setup

setup(
    name = "paquete_mats",
    version = "1.0",
    description = " paquete de funciones matematicas",
    author = "Laudrup",
    packages=["paquete"],
    )